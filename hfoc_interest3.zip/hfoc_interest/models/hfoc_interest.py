from odoo import models, fields, api, _
from odoo.exceptions import UserError, Warning
import pytz
from datetime import datetime, timedelta, date, time
import json


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    hfoc_inicial = fields.Boolean(string='Es una inicial?',  copy=False)   

class ConfigInterestInvoice(models.Model):
    _name = 'config.interest.invoice'

    name = fields.Char(string='Descripcion', required=True, copy=False)
    tasa = fields.Float(string='Factor interes', copy=False)
    product_interest = fields.Many2one('product.product', required=True, string='Producto Interes')
    impuesto = fields.Many2many('account.tax', 'imp','gen', required=True, string='Impuesto')


class AccountPaymentTerm(models.Model):
    _inherit = 'account.payment.term'
    
    product_interest = fields.Many2one('product.product', string='Producto Financiamiento')
    porcentaje_interes = fields.Float(string='Tasa %',  copy=False)
    

class AccountCronoReg(models.Model):
    _name = 'account.crono.reg'
   
    name = fields.Char(string='Cuota N°',  copy=False)
    monto = fields.Float(string='Monto',  copy=False)
    monto_pagado = fields.Float(string='Pagado', compute='calcular_cuota' , copy=False)
    interes_generado = fields.Float(string='Interes', copy=False)
    date = fields.Date(string='Fecha', copy= False)
    description = fields.Char(string='Descripción' , copy= False)
    state = fields.Char(string='Estado', compute='state_cal', copy= False )
    invoice_id = fields.Many2one('account.invoice',   string='Factura', copy=False)
    invoice_interest = fields.Many2one('account.invoice',  string='Factura', copy=False)

    @api.one
    def state_cal(self):
        if self.monto <= self.monto_pagado:
            self.state = "Pagado"
        elif self.monto_pagado > 0:
            self.state = "Amortizado"
        elif self.monto_pagado == 0:
            self.state = "Pendiente"

    @api.one
    def calcular_cuota(self):         
        d1 = str(self.invoice_id.dict_pagos)
        s1 = json.dumps(d1)
        d2 = json.loads(s1)
        d2 = eval(d2)            
        self.monto_pagado = d2[str(self.id)]    
    
    @api.one
    def generar_interest(self):

        if not self.invoice_id.interest_invoice:
            raise UserError(_('Primero debe seleccionar la tasa de interes.'))       
        total_interes = 0.0
        current_date = date.today()
        date_format = '%Y-%m-%d'
        a = datetime.strptime(str(self.date), date_format)
        b = datetime.strptime(str(current_date), date_format)
        delta = (b - a).days
        
        if delta > 0:
            total_interes = self.invoice_id.interest_invoice.tasa * delta * self.monto_pagado
            self.interes_generado = total_interes
        else:            
            raise UserError(_('Esta cuota aun no puede generar interes, la fecha aun no vence.'))    

        vals = {           
            'type': self.invoice_id.type, 
            'partner_id': self.invoice_id.partner_id.id,
            'journal_id': self.invoice_id.journal_id.id,
            'company_id': self.env.user.company_id.id,
            'origin': str(self.invoice_id.number),
            'account_id': self.invoice_id.account_id.id,            
            'invoice_line_ids': [
                (0,0,{
                    "product_id": self.invoice_id.interest_invoice.product_interest.id or "",
                    "name": 'Intereses generado desde el comprobante ' + str(self.invoice_id.number),
                    "account_id": 175, 
                    "price_unit": total_interes,                                 

                }),                
            ]
        }

        self.invoice_interest = self.invoice_interest.create(vals)
        for line in self.invoice_interest:
            for tax in line.invoice_line_ids:
                tax.invoice_line_tax_ids = self.invoice_id.interest_invoice.impuesto or ""


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'

    num_cuotas = fields.Integer(string='Numero de cuotas', default=1, required=True, copy=False)
    num_days_range = fields.Integer(string='Dias', default=1, required=True, copy=False)
    crono_reg = fields.Many2many('account.crono.reg', 'crono','reg', string='Cronograma', copy=False )  
    interest_invoice = fields.Many2one('config.interest.invoice',  string='Tasa de interes por dia:', default=lambda self: self.env['config.interest.invoice'].search([], limit=1 ) , copy=False)    
    origin_invoice_ids = fields.Many2many('account.invoice', 'origin','interest_ids', string='Origen de factura', copy=False)    
    crono_html = fields.Html(string='Cronograma', compute='info_html',  copy=False)
    monto_inicial = fields.Float(string='Inicial', compute='comp_monto_incial' , copy=False)
    monto_cuota = fields.Float(string='Cuota', compute='comp_monto_cuota' , copy=False)
    deuda_pendiente = fields.Float(string='deuda total', copy=False)
    monto_pagado = fields.Float(string='Monto pagado', compute='comp_monto_pagado' , copy=False)
    dict_pagos = fields.Text(string='Dict', compute='dict_pagos_cal' , copy=False)
    porcentaje_interes = fields.Float(string='Porcentaje %', copy=False)
    inicial_estimada = fields.Float(string='Inicial estimada', copy=False)
    aux_interes = fields.Float(string='Aux', copy=False)


    @api.one
    def calcular_linea_interes(self):
        self.payment_term_id.product_interest.taxes_id
        self.payment_term_id.porcentaje_interes
        total = 0
        for sun in self.invoice_line_ids:
            if sun.product_id.id != self.payment_term_id.product_interest.id:   
                total += sun.price_unit
        interes = 0.0
        interes_first = (self.payment_term_id.porcentaje_interes*(self.amount_total-self.inicial_estimada))/100        
        aux = 0
        for line in self.invoice_line_ids:
            if line.product_id.id == self.payment_term_id.product_interest.id:                
                interes = (self.payment_term_id.porcentaje_interes*(total-self.inicial_estimada))/100
                line.update({'price_unit': interes})                
                self.aux_interes = interes
                aux = 1

        self._onchange_invoice_line_ids()
        if aux == 0:
            vals = { 
                "product_id": self.payment_term_id.product_interest.id or "",
                "name": 'Financiamiento %' + str(self.payment_term_id.porcentaje_interes) ,
                "account_id": 175, 
                "price_unit": interes_first,
            }

            self.invoice_line_ids = self.invoice_line_ids + self.invoice_line_ids.create(vals)
            self.aux_interes = interes_first
        if self.payment_term_id.product_interest.id:            
            for tax in self.invoice_line_ids:
                if tax.product_id.id == self.payment_term_id.product_interest.id:
                    if not tax.invoice_line_tax_ids:
                        tax.invoice_line_tax_ids = self.payment_term_id.product_interest.taxes_id or ""
                        self._onchange_invoice_line_ids()

    @api.one
    def info_html(self):        
        self.crono_html =  "<div style='background: #c1ceff;border-left: solid #2196F3 3px;padding: 3px;' ><strong>Total facturado: </strong>"+ str(self.amount_total) + "<br></br><strong>Total inicial: </strong>"""+ str(self.monto_inicial) + "<br></br><strong>Total de cuotas: </strong> " +str(len(self.crono_reg)) + "</div>"

    @api.one
    def comp_monto_incial(self):
        for inicial in self.payment_ids:
            if inicial.hfoc_inicial == True:
                self.monto_inicial += inicial.amount
    
    @api.one
    def comp_monto_total(self):
        self.deuda_pendiente = self.amount_total - self.monto_inicial    
    
    @api.one
    def comp_monto_cuota(self):
        if len(self.crono_reg) > 0 :
            self.monto_cuota = (self.amount_total - self.monto_inicial) / len(self.crono_reg)
    
    @api.one
    def comp_monto_pagado(self):
        self.monto_pagado = self.amount_total - self.residual - self.monto_inicial

    @api.one
    def dict_pagos_cal(self):
        # if self.date_due and self.date_invoice and self.num_cuotas > 0:
        dict_cuotas = {}
        count_cuotas = len(self.crono_reg)
        cuotas_list = []
        dif = 0
        aux = 0
        if count_cuotas > 0:
            cuotas_validadas = self.monto_pagado // self.monto_cuota
            cuotas_enteras = int(cuotas_validadas)
            cuota_parcial = self.monto_pagado - (cuotas_enteras * self.monto_cuota)        
            for e in range(cuotas_enteras):            
                cuotas_list.append(self.monto_cuota)
            if cuota_parcial > 0:
                cuotas_list.append(cuota_parcial)            
            if len(cuotas_list) < count_cuotas:
                dif = count_cuotas - int(len(cuotas_list))         
            if dif > 0:
                for d in range(dif):
                    cuotas_list.append(0)
            
            for line in self.crono_reg: 
                dict_cuotas[str(line.id)] = cuotas_list[aux]                
                aux += 1
        self.dict_pagos = dict_cuotas

    @api.one
    def cronograma_reg(self):
        if not self.date_invoice or not self.date_due:
            raise UserError(_('Debe fija la Fecha de factura y Fecha de vencimiento'))    

        for i in range(self.num_cuotas):            
            vals = {
                    'name': "", 
                    'invoice_id': self.id or "",   
                }
            ids_cuota = self.crono_reg.create(vals)
            self.crono_reg += ids_cuota

        count_cuotas = len(self.crono_reg)
        aux = 0
        aument = 0

        date_format = '%Y-%m-%d'
        a = datetime.strptime(str(self.date_invoice), date_format)
        b = datetime.strptime(str(self.date_due), date_format)
        delta = (b - a).days
        if delta < 0:
            raise UserError(_('No puedes generar un cronograma si no hay una diferencia mayor a 1 dia entre la fecha de factura y vencimiento.'))   
        cuotas_cociente = delta // count_cuotas
        cuotas_resto = delta % count_cuotas
        
        for line in self.crono_reg:
            if cuotas_resto > 0:
                aument += cuotas_cociente + 1
                cuotas_resto = cuotas_resto - 1                    
            else:
                aument += cuotas_cociente
            fecha = str((a + timedelta(days=aument) ).strftime(date_format))

            line.name = "Cuota N° " + str(aux+1)
            line.monto = self.monto_cuota
            line.date = fecha
            aux += 1         
    

