{
    'name': "HFOC Interest",

    'summary': """
        HFOC Interest
        """,

    'description': """
        HFOC Interest
    """,

    'author': "HFOC",
    'email': "hfoc11@gmail.com",
    'category': 'account',
    'version': '0.1',
    "installable": True,

    'depends': ['base','account'],

    'data': [       
        'views/account_invoice_inherit.xml',
        'views/config_interest_invoice.xml',   
        'views/account_payment_inherit.xml', 
        'views/account_payment_term_inherit.xml', 
            
  
    ],
  
  
}